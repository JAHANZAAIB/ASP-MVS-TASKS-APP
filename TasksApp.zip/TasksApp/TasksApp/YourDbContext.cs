﻿internal class YourDbContext
{
}