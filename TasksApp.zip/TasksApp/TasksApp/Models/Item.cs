﻿using System.ComponentModel.DataAnnotations;

namespace TasksApp.Models
{
    public class Item
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Task name is required")]
        public required string Name { get; set; }

        public string? Description { get; set; }

        [Required(ErrorMessage = "Due date is required")]
        [DataType(DataType.Date)]
        [CustomValidation(typeof(Item), nameof(ValidateDueDate))]
        public DateTime DueDate { get; set; }

        public int Status { get; set; }

        public static ValidationResult ValidateDueDate(DateTime dueDate, ValidationContext context)
        {
            if (dueDate < DateTime.Today)
            {
                return new ValidationResult("Due date cannot be in the past.");
            }

            return ValidationResult.Success;
        }
    }
}
