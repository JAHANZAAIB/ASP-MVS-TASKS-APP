﻿using Microsoft.AspNetCore.Mvc;
using TasksApp.Data;
using Microsoft.EntityFrameworkCore;
using TasksApp.Models;

namespace TasksApp.Controllers
{
    public class ItemsController : Controller
    {
        private readonly TasksAppContext _context;
        public ItemsController(TasksAppContext context)
        {
            _context = context;
        }

        //get
        public async Task<IActionResult> Index()
        {
            var items = await _context.Items.ToListAsync();

            return View(items);
        }

        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create([Bind("Id,Name,Description,DueDate")] Item items)
        {
            if (ModelState.IsValid)
            {
                _context.Add(items);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(items);
        }

        public async Task<IActionResult> Edit (int id)
        {
            if (id == 0)
                return NotFound();

            var item = await _context.Items.FirstOrDefaultAsync(x =>x.Id == id);
            if (item == null)
                return NotFound();

            return View(item);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Description,DueDate")] Item item)
        {
            if (ModelState.IsValid)
            {
                _context.Update(item);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(item);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var item = await _context.Items.FindAsync(id);
            if (item != null)
            {
                _context.Items.Remove(item);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> ChangeStatus(int id, int status)
        {
            var item = await _context.Items.FindAsync(id);
            
            if (item == null)
                return NotFound();

            item.Status = status;
            _context.Update(item);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }



        }
}
