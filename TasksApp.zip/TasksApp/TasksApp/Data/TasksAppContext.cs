﻿namespace TasksApp.Data;
using TasksApp.Models;
using Microsoft.EntityFrameworkCore;

public class TasksAppContext : DbContext
{
    public TasksAppContext(DbContextOptions<TasksAppContext> options)
        : base(options)
    {
    }
    public DbSet<Item> Items { get; set; } = null!;
}